import dialogflow
import time
#from naoqi import ALProxy
import speech_recognition as sr
import pyttsx

#project id: agent2-284f9

def detect_intent_texts(project_id, session_id, texts, language_code):
    session_client = dialogflow.SessionsClient()

    session = session_client.session_path(project_id, session_id)
    #print('Session path: {}\n'.format(session))

    for text in texts:
        text_input = dialogflow.types.TextInput(text=text, language_code=language_code)
        query_input = dialogflow.types.QueryInput(text=text_input)
        response = session_client.detect_intent(session=session, query_input=query_input)

        #print('Fulfillment text: {}\n'.format(response.query_result.fulfillment_text))
        #print('Pepper: {}\n'.format(response.query_result.fulfillment_text))
        return 'Pepper: {}\n'.format(response.query_result.fulfillment_text)
        #tts = ALProxy("ALTextToSpeech", "<IP address>", 9559)


#detect_intent_texts("agent2-284f9","abcd",["how old are you"],"en-US")
'''
user_text = input()
#print(user_text)
detect_intent_texts("agent2-284f9","abcd",[user_text],"en-US")
'''

def recognize_speech_from_mic(recognizer, microphone):
    
    # check that recognizer and microphone arguments are appropriate type
    if not isinstance(recognizer, sr.Recognizer):
        raise TypeError("`recognizer` must be `Recognizer` instance")

    if not isinstance(microphone, sr.Microphone):
        raise TypeError("`microphone` must be `Microphone` instance")

    # adjust the recognizer sensitivity to ambient noise and record audio
    # from the microphone
    with microphone as source:
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    # set up the response object
    response = {
        "success": True,
        "error": None,
        "transcription": None
    }

    # try recognizing the speech in the recording
    # if a RequestError or UnknownValueError exception is caught,
    #     update the response object accordingly
    try:
        response["transcription"] = recognizer.recognize_google(audio)
    except sr.RequestError:
        # API was unreachable or unresponsive
        response["success"] = False
        response["error"] = "API unavailable"
    except sr.UnknownValueError:
        # speech was unintelligible
        response["error"] = "Unable to recognize speech"

    return response

def main():
    print("SPEAK\n")
    while True:
        #tts = ALProxy("ALTextToSpeech", "<IP address>", 9559)
        #print('User:')
        #user_text = raw_input("User: ")

        #get audio from user
        recognizer = sr.Recognizer()
        microphone = sr.Microphone()
#        user_audio_dict = recognize_speech_from_mic(recognizer, microphone)
        for j in range(5):
            user_audio_dict = recognize_speech_from_mic(recognizer, microphone)
            if user_audio_dict["transcription"]:
                break
            if not user_audio_dict["success"]:
                break
            print("I'm sorry, what was that again?\n")
        
       # engine = pyttsx.init()
        user_audio = format(user_audio_dict["transcription"])
        print("User: " + user_audio)
        #print("User: {}".format(user_audio_dict["transcription"]))
        user_text = str(user_audio)
        start_time = time.time()
        pepper_answer = detect_intent_texts("agent2-284f9","abcd",[user_text],"en-US")        
        end_time = time.time()
        print(str(pepper_answer) + "\ttime(s): " + str(end_time - start_time))
      #  engine.say(pepper_answer)
      #  engine.runAndWait()
    '''
        start_time = time.time()
        pepper_answer = detect_intent_texts("agent2-284f9","abcd",[user_text],"en-US")
        end_time = time.time()
        print(str(pepper_answer) + "\ttime(s):" + str(end_time - start_time))
#        tts = ALProxy("ALTextToSppech", "10.207.126.196", 9559)
#        tts.say(pepper_answer)
'''
main()
