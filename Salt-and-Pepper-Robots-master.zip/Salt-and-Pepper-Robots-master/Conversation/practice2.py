import dialogflow
import time
#from naoqi import ALProxy

#project id: agent2-284f9

def detect_intent_texts(project_id, session_id, texts, language_code):
    session_client = dialogflow.SessionsClient()

    session = session_client.session_path(project_id, session_id)
    #print('Session path: {}\n'.format(session))

    for text in texts:
        text_input = dialogflow.types.TextInput(text=text, language_code=language_code)
        query_input = dialogflow.types.QueryInput(text=text_input)
        response = session_client.detect_intent(session=session, query_input=query_input)

        #print('Fulfillment text: {}\n'.format(response.query_result.fulfillment_text))
        #print('Pepper: {}\n'.format(response.query_result.fulfillment_text))
        return 'Pepper: {}\n'.format(response.query_result.fulfillment_text)
        #tts = ALProxy("ALTextToSpeech", "<IP address>", 9559)


#detect_intent_texts("agent2-284f9","abcd",["how old are you"],"en-US")
'''
user_text = input()
#print(user_text)
detect_intent_texts("agent2-284f9","abcd",[user_text],"en-US")
'''

def main():
    while True:
        #tts = ALProxy("ALTextToSpeech", "<IP address>", 9559)
        #print('User:')
        user_text = raw_input("User: ")
        start_time = time.time()
        pepper_answer = detect_intent_texts("agent2-284f9","abcd",[user_text],"en-US")
        end_time = time.time()
        print(str(pepper_answer) + "\ttime(s):" + str(end_time - start_time))
#        tts = ALProxy("ALTextToSppech", "10.207.126.196", 9559)
#        tts.say(pepper_answer)

main()
